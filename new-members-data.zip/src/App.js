import "./App.css";
import TeamMembers from "./Components/TeamMembers";

function App() {
  return <div className="App">
    <TeamMembers/>
  </div>;
}

export default App;
